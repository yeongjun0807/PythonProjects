from cx_Freeze import setup, Executable

# Dependencies are automatically detected, but it might need
# fine tuning.
buildOptions = dict(packages = [], excludes = [])

import sys
base = 'Win32GUI' if sys.platform=='win32' else None

executables = [
    Executable('Ip_Address_To_Bin.py', base=base, icon = "IP.ico")
]

setup(name='Ip_Address_To_Bin',
      version = '1.0',
      description = 'None',
      options = dict(build_exe = buildOptions),
      executables = executables)
