from tkinter import *
from tkinter import ttk

def Transform(key):
    YourIpAddress = InputBox.get()
    IPlist = YourIpAddress.split('.')
    BinIPlist = []
    Password = 128

    for ip in IPlist:
        BinIPlist.append(bin(int(ip)))

    BinIpAddress =  ''
    EncryptIpAddress = ''

    i = 0

    for bip in BinIPlist:
        BinIpAddress += bip[2:].zfill(8)
        EncryptIpAddress += str(int(bip[2:].zfill(8)) ^ Password)

        if i < len(BinIPlist) - 1:
            BinIpAddress += '.'
            EncryptIpAddress += '.'

        i += 1

    if len(EncryptIpAddress) > 30:
        Result_Label.configure(width = 30)
        window.geometry("520x45")

    else:
        Result_Label.configure(width = 13)
        window.geometry("330x45")

    Result_Label.configure(text = EncryptIpAddress)
    Password_Label.configure(text = Password)


window = Tk()
window.geometry("330x45")
window.title("Ip_Address_To_Bin")
window.resizable(False, False)
window.configure(background = 'blue')
window.iconbitmap("IP.ico")

InputBox = Entry(window, width = 13, font = "Jalnan")
Same_Sign_Label = Label(window, font = "Jalnan", text = "=")
Result_Label = Label(window, font = "Jalnan", text = None, width = 13)
Password_Label = Label(window, font = "Jalnan", text = None, width = 5)

InputBox.grid(column = 0, row = 1, padx = 5)
Same_Sign_Label.grid(column = 1, row = 1, padx = 5)
Result_Label.grid(column = 2, row = 1, padx = 5)
Password_Label.grid(column = 2, row = 2, padx = 5, pady = 2)

window.bind('<Return>', Transform)
window.mainloop()
